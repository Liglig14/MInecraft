@echo off
title Minecraft World Backup Setup
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
if errorlevel 1 (
    echo.
    echo Setup encountered an error. Check the message above.
    pause
)
