$ErrorActionPreference = "Stop"

# Request administrator access only when needed.
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "Requesting administrator permission..."
    $argsList = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $argsList
    exit
}

$taskName = "Minecraft World Auto Backup"
$sourceExe = Join-Path $PSScriptRoot "Uploader.exe"
$installDir = Join-Path $env:LOCALAPPDATA "MinecraftWorldBackup"
$installedExe = Join-Path $installDir "Uploader.exe"
$worldPath = Join-Path $env:APPDATA ".minecraft\saves\New World"

Write-Host ""
Write-Host "============================================"
Write-Host "      Minecraft World Backup Setup"
Write-Host "============================================"
Write-Host ""

if (-not (Test-Path $sourceExe)) {
    throw "Uploader.exe is missing. Keep it beside Setup.bat and Install.ps1."
}

if (-not (Test-Path (Join-Path $worldPath "level.dat"))) {
    Write-Host "The world 'New World' was not found at:"
    Write-Host $worldPath
    Write-Host ""
    Write-Host "Copy your New World folder into .minecraft\saves first."
    throw "Minecraft world folder is missing."
}

New-Item -ItemType Directory -Path $installDir -Force | Out-Null
Copy-Item -Path $sourceExe -Destination $installedExe -Force
Write-Host "Uploader installed to: $installedExe"

Write-Host ""
Write-Host "Enabling Windows process-start event recording..."
& auditpol.exe /set /subcategory:"Process Creation" /success:enable
if ($LASTEXITCODE -ne 0) {
    throw "Could not enable Process Creation auditing."
}

$auditRegistryPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit"
New-Item -Path $auditRegistryPath -Force | Out-Null
New-ItemProperty -Path $auditRegistryPath `
    -Name "ProcessCreationIncludeCmdLine_Enabled" `
    -PropertyType DWord -Value 1 -Force | Out-Null

Write-Host ""
Write-Host "The installer needs to identify Minecraft's Java runtime."
Write-Host "1. Launch Minecraft from TLauncher."
Write-Host "2. Wait until you reach the Minecraft main menu."
Write-Host "3. Return to this window and press Enter."
Write-Host ""
Read-Host "Press Enter after Minecraft has reached the main menu"

$javaPath = $null
$cutoff = (Get-Date).AddMinutes(-20)
$events = Get-WinEvent -FilterHashtable @{
    LogName = "Security"
    Id = 4688
    StartTime = $cutoff
} -ErrorAction SilentlyContinue

foreach ($event in $events) {
    try {
        [xml]$eventXml = $event.ToXml()
        $eventData = @{}
        foreach ($item in $eventXml.Event.EventData.Data) {
            $eventData[[string]$item.Name] = [string]$item.'#text'
        }

        $candidate = $eventData["NewProcessName"]
        $commandLine = $eventData["CommandLine"]

        if (
            $candidate -and
            ([IO.Path]::GetFileName($candidate) -ieq "javaw.exe") -and
            $commandLine -and
            $commandLine.Contains("net.fabricmc.loader.impl.launch.knot.KnotClient")
        ) {
            $javaPath = $candidate
            break
        }
    } catch {
        # Ignore malformed or unrelated Security events.
    }
}

if (-not $javaPath) {
    Write-Host ""
    Write-Host "Minecraft's Fabric Java process was not found in recent events."
    Write-Host "Make sure you launched the game itself, not just the TLauncher."
    Write-Host "Run Setup.bat again after launching Minecraft."
    throw "Could not identify Minecraft's Java runtime."
}

Write-Host ""
Write-Host "Minecraft runtime found:"
Write-Host $javaPath

# Build the Windows Event Log trigger for this exact javaw.exe path.
$subscription = @"
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and EventID=4688] and EventData[Data[@Name='NewProcessName']='$javaPath']]</Select>
  </Query>
</QueryList>
"@

$userSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value

$taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>Automatically backs up the New World Minecraft save after the game closes.</Description>
  </RegistrationInfo>
  <Triggers>
    <EventTrigger>
      <Enabled>true</Enabled>
      <Subscription><![CDATA[$subscription]]></Subscription>
    </EventTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>$userSid</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <Enabled>true</Enabled>
    <Hidden>true</Hidden>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <StartWhenAvailable>true</StartWhenAvailable>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>$installedExe</Command>
    </Exec>
  </Actions>
</Task>
"@

Register-ScheduledTask -TaskName $taskName -Xml $taskXml -Force | Out-Null

Write-Host ""
Write-Host "============================================"
Write-Host "          SETUP COMPLETED"
Write-Host "============================================"
Write-Host "Automatic backup task: $taskName"
Write-Host "Uploader location: $installedExe"
Write-Host ""
Write-Host "Your backups will upload after you close Minecraft."
Write-Host "The temporary ZIP is deleted after a successful upload."
Write-Host "You can close this window."
Write-Host ""
