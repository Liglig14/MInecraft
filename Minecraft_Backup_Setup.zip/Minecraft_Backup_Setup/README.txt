MINECRAFT WORLD BACKUP SETUP

FILES
- Setup.bat: run this to configure a Windows PC.
- Install.ps1: setup script called by Setup.bat.
- Uploader.exe: your existing uploader, already configured for your GitHub repository.

BEFORE RUNNING SETUP ON ANOTHER PC
1. Install TLauncher and launch the same Fabric Minecraft version at least once.
2. Put your world folder named "New World" in:
   %APPDATA%\.minecraft\saves\New World
   The folder should contain level.dat.
3. Extract this package to a normal folder.
4. Double-click Setup.bat and approve the administrator prompt.
5. When the setup window asks, launch Minecraft and wait for the main menu.
6. Return to the setup window and press Enter.
7. Wait for SETUP COMPLETED.

AFTER SETUP
- Launch Minecraft normally.
- Play as usual.
- Close Minecraft normally.
- The uploader will wait for the game to close, create a ZIP, and upload it as a GitHub Release.
- The temporary ZIP is deleted only after GitHub confirms the upload.

IMPORTANT
- This package contains your GitHub access token inside Uploader.exe.
  Keep the package and EXE private. Anyone who obtains the EXE may be able
  to extract the token and use its repository permissions.
- The uploader currently targets a world folder named "New World".
- The package does not include your Minecraft world. Transfer or restore
  the world separately before running setup.
- This setup is for Windows PCs with the same Minecraft Java/Fabric launch
  style. If the runtime or launcher changes, setup may need adjustment.
- If setup cannot identify Minecraft, launch the actual game (not only
  TLauncher), then run Setup.bat again.
